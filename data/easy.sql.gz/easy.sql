-- phpMyAdmin SQL Dump
-- version 3.3.7deb5build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2011 at 11:54 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `easy`
--

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `company` varchar(255) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `position` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `how_to_apply` text NOT NULL,
  `token` varchar(255) NOT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `is_activated` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `category_id_idx` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`id`, `category_id`, `type`, `company`, `logo`, `url`, `position`, `location`, `description`, `how_to_apply`, `token`, `is_public`, `is_activated`, `email`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 2, 'full-time', 'Sensio Labs', 'sensio-labs.gif', 'http://www.sensiolabs.com/', 'Web Developer', 'Paris, France', 'You''ve already developed websites with symfony and you want to work\nwith Open-Source technologies. You have a minimum of 3 years\nexperience in web development with PHP or Java and you wish to\nparticipate to development of Web 2.0 sites using the best\nframeworks available.\n', 'Send your resume to fabien.potencier [at] sensio.com\n', 'job_sensio_labs', 1, 1, 'job@example.com', '2009-01-30 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(2, 1, 'part-time', 'Extreme Sensio', 'extreme-sensio.gif', 'http://www.extreme-sensio.com/', 'Web Designer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do\neiusmod tempor incididunt ut labore et dolore magna aliqua. Ut\nenim ad minim veniam, quis nostrud exercitation ullamco laboris\nnisi ut aliquip ex ea commodo consequat. Duis aute irure dolor\nin reprehenderit in.\n\nVoluptate velit esse cillum dolore eu fugiat nulla pariatur.\nExcepteur sint occaecat cupidatat non proident, sunt in culpa\nqui officia deserunt mollit anim id est laborum.\n', 'Send your resume to fabien.potencier [at] sensio.com\n', 'job_extreme_sensio', 1, 1, 'job@example.com', '2009-01-30 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(3, 2, NULL, 'Sensio Labs', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] dolor.sit', 'job_expired', 1, 1, 'job@example.com', '2005-12-01 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(4, 2, NULL, 'Company 100', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_100.sit\n', 'job_100', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(5, 2, NULL, 'Company 101', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_101.sit\n', 'job_101', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(6, 2, NULL, 'Company 102', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_102.sit\n', 'job_102', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(7, 2, NULL, 'Company 103', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_103.sit\n', 'job_103', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(8, 2, NULL, 'Company 104', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_104.sit\n', 'job_104', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(9, 2, NULL, 'Company 105', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_105.sit\n', 'job_105', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(10, 2, NULL, 'Company 106', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_106.sit\n', 'job_106', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(11, 2, NULL, 'Company 107', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_107.sit\n', 'job_107', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(12, 2, NULL, 'Company 108', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_108.sit\n', 'job_108', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(13, 2, NULL, 'Company 109', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_109.sit\n', 'job_109', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(14, 2, NULL, 'Company 110', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_110.sit\n', 'job_110', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(15, 2, NULL, 'Company 111', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_111.sit\n', 'job_111', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(16, 2, NULL, 'Company 112', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_112.sit\n', 'job_112', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(17, 2, NULL, 'Company 113', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_113.sit\n', 'job_113', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(18, 2, NULL, 'Company 114', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_114.sit\n', 'job_114', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(19, 2, NULL, 'Company 115', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_115.sit\n', 'job_115', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(20, 2, NULL, 'Company 116', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_116.sit\n', 'job_116', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(21, 2, NULL, 'Company 117', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_117.sit\n', 'job_117', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(22, 2, NULL, 'Company 118', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_118.sit\n', 'job_118', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(23, 2, NULL, 'Company 119', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_119.sit\n', 'job_119', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(24, 2, NULL, 'Company 120', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_120.sit\n', 'job_120', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(25, 2, NULL, 'Company 121', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_121.sit\n', 'job_121', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(26, 2, NULL, 'Company 122', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_122.sit\n', 'job_122', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(27, 2, NULL, 'Company 123', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_123.sit\n', 'job_123', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(28, 2, NULL, 'Company 124', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_124.sit\n', 'job_124', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(29, 2, NULL, 'Company 125', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_125.sit\n', 'job_125', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(30, 2, NULL, 'Company 126', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_126.sit\n', 'job_126', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(31, 2, NULL, 'Company 127', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_127.sit\n', 'job_127', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(32, 2, NULL, 'Company 128', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_128.sit\n', 'job_128', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(33, 2, NULL, 'Company 129', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_129.sit\n', 'job_129', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54'),
(34, 2, NULL, 'Company 130', NULL, NULL, 'Web Developer', 'Paris, France', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Send your resume to lorem.ipsum [at] company_130.sit\n', 'job_130', 1, 1, 'job@example.com', '0000-00-00 00:00:00', '2011-04-19 00:21:54', '2011-04-19 00:21:54');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `job`
--
ALTER TABLE `job`
  ADD CONSTRAINT `job_category_id_job_category_id` FOREIGN KEY (`category_id`) REFERENCES `job_category` (`id`);
